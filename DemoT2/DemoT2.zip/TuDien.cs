﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DemoT2
{
    public class TuDien
    {
        public string Word { get; set; }
        public string Mean { get; set; }

        public override string ToString()
        {
            return Word;
        }
    }
}
